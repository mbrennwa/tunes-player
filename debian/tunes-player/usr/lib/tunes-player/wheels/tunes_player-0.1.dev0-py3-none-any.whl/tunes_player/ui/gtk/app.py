"""Libadwaita main window and application entry."""

from __future__ import annotations

import logging
import threading

import gi

gi.require_version("Adw", "1")
gi.require_version("Gtk", "4.0")

from gi.repository import Adw, Gio, GLib, Gtk  # noqa: E402

from tunes_player.core.logging_config import configure_logging
from tunes_player.core.models import Release, Source
from tunes_player.core.services import PlayerService
from tunes_player.core.shell_state import (
    ShellBase,
    ShellState,
    apply_source_filter,
    release_to_cache_payload,
    releases_from_cache_payloads,
)
from tunes_player.platform.linux.audio import create_volume_controller
from tunes_player.ui.gtk.art import ArtLoader
from tunes_player.ui.gtk.errors import attach_error_toasts, show_error_toast
from tunes_player.ui.gtk.now_playing import NowPlayingBar, attach_media_keys
from tunes_player.ui.gtk.preferences import PreferencesWindow
from tunes_player.ui.gtk.shell_controller import available_sources, fetch_base_releases
from tunes_player.ui.gtk.source_multi_switch import SourceMultiSwitch
from tunes_player.ui.gtk.util import escape_markup, load_app_css, source_label
from tunes_player.ui.gtk.views import (
    LoadingDiscoverView,
    PlaceholderView,
    QueueSheet,
    ReleaseDetailView,
    ReleaseGridView,
)
from tunes_player.ui.gtk.album_grid import ALBUM_GRID_VIEW_MARGIN, album_grid_min_content_width

_APP_WINDOW_TITLE = "Tunes Player"
_DEFAULT_SIZE = (960, 640)
_GRID_ROOT_TAG = "grid-root"
_PERSIST_DEBOUNCE_MS = 400
_ONBOARDING_MESSAGE = (
    "Configure music sources in Settings, then search or choose New Releases."
)
_PRESET_LABELS = {
    ShellBase.NEW_MUSIC: "New Releases",
    ShellBase.SUGGESTION: "Suggest Music",
}
_LOADING_MESSAGES = {
    ShellBase.NEW_MUSIC: "Loading new releases…",
    ShellBase.SUGGESTION: "Finding suggestions...",
}

log = logging.getLogger(__name__)


class TunesWindow(Adw.ApplicationWindow):
    def __init__(self, *, application: Adw.Application, service: PlayerService) -> None:
        super().__init__(application=application, title=_APP_WINDOW_TITLE)
        self._service = service
        self._art_loader = ArtLoader(service.config.data_dir)
        self._shell_state = self._load_initial_shell_state()
        self._load_token = 0
        self._persist_timeout_id = 0
        self._updating_chips = False
        self._preferences: PreferencesWindow | None = None
        self._queue_sheet: QueueSheet | None = None
        self._source_multi: SourceMultiSwitch | None = None
        self._cached_selection_key: tuple[str, str] | None = None
        self._cached_releases: list[Release] = []
        self.set_default_size(*_DEFAULT_SIZE)

        self._now_playing = NowPlayingBar(service=service, art_loader=self._art_loader)
        self._now_playing.set_queue_handler(self._open_queue_sheet)
        self._now_playing.set_play_handler(self._on_play_clicked)

        self._toolbar = Adw.ToolbarView()
        self._toolbar.set_size_request(-1, -1)
        self._toolbar.add_bottom_bar(self._now_playing)
        self.set_content(self._toolbar)

        self._toast_overlay = Adw.ToastOverlay()
        self._toast_overlay.set_size_request(-1, -1)
        self._build_shell()
        attach_media_keys(self, service)
        attach_error_toasts(self._toast_overlay, service)
        service.subscribe(lambda event: GLib.idle_add(self._on_service_event, event))
        self.connect("close-request", self._on_close_request)
        GLib.idle_add(self._startup_playback_probe)
        GLib.idle_add(self._reload_grid)

    def _load_initial_shell_state(self) -> ShellState:
        state = self._service.config.config.shell_state
        if not available_sources(self._service):
            return ShellState()
        sources = available_sources(self._service)
        if state.enabled_sources and not state.enabled_sources <= sources:
            state = ShellState(
                base=state.base,
                search_query=state.search_query,
                enabled_sources=state.enabled_sources & sources,
            )
        return state

    def _build_shell(self) -> None:
        self._header = Adw.HeaderBar()
        self._toolbar.add_top_bar(self._header)

        self._window_title = Adw.WindowTitle(title=_APP_WINDOW_TITLE, subtitle="")
        title_center = Gtk.Box()
        title_center.set_halign(Gtk.Align.CENTER)
        title_center.append(self._window_title)
        self._header.set_title_widget(title_center)

        self._back_btn = Gtk.Button(icon_name="go-previous-symbolic")
        self._back_btn.set_tooltip_text("Back")
        self._back_btn.set_visible(False)
        self._back_btn.connect("clicked", self._on_nav_back)
        self._header.pack_start(self._back_btn)

        settings_action = Gio.SimpleAction.new("settings", None)
        settings_action.connect("activate", lambda *_a, **_k: self._open_preferences())
        self.add_action(settings_action)

        settings_btn = Gtk.MenuButton(icon_name="emblem-system-symbolic")
        settings_btn.set_tooltip_text("Settings")
        menu = Gio.Menu.new()
        menu.append("Settings", "win.settings")
        settings_btn.set_menu_model(menu)
        self._header.pack_end(settings_btn)

        shell_column = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        shell_column.set_vexpand(True)
        shell_column.set_hexpand(True)

        controls = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        controls.add_css_class("shell-controls")
        controls.set_margin_top(8)
        controls.set_margin_bottom(4)
        controls.set_margin_start(12)
        controls.set_margin_end(12)

        search_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        search_row.add_css_class("linked")
        search_row.add_css_class("shell-search-row")
        search_row.set_hexpand(True)
        self._search_entry = Gtk.SearchEntry()
        self._search_entry.add_css_class("shell-search-entry")
        self._search_entry.set_placeholder_text("Search releases…")
        self._search_entry.set_hexpand(True)
        self._search_entry.connect("activate", self._on_search_activate)
        search_row.append(self._search_entry)

        self._new_music_btn = Gtk.ToggleButton(label="New Releases")
        self._new_music_btn.add_css_class("shell-preset-btn")
        self._new_music_btn.connect("toggled", self._on_new_music_toggled)
        search_row.append(self._new_music_btn)

        self._suggestion_btn = Gtk.ToggleButton(label="Suggest Music")
        self._suggestion_btn.add_css_class("shell-preset-btn")
        self._suggestion_btn.connect("toggled", self._on_suggestion_toggled)
        search_row.append(self._suggestion_btn)

        controls.append(search_row)

        self._source_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self._source_row.add_css_class("shell-source-row")
        controls.append(self._source_row)

        self._shell_controls = controls
        shell_column.append(controls)

        self._main_nav = Adw.NavigationView()
        self._main_nav.set_vexpand(True)
        self._main_nav.set_hexpand(True)
        self._main_nav.connect("notify::visible-page", self._on_nav_visible_page_changed)
        shell_column.append(self._main_nav)

        self._toast_overlay.set_child(shell_column)
        self._toolbar.set_content(self._toast_overlay)

        self._apply_window_min_width()
        self._rebuild_source_filters()
        self._sync_shell_controls()

    def _apply_window_min_width(self) -> None:
        min_width = album_grid_min_content_width()
        _min_w, min_h = self.get_size_request()
        if min_h < 0:
            min_h = 400
        self.set_size_request(min_width, min_h)

    def _album_grid_inner_width(self) -> int:
        window_width = self.get_width()
        if window_width < 64:
            return 0
        return max(0, window_width - 2 * ALBUM_GRID_VIEW_MARGIN)

    def _effective_shell_state(self) -> ShellState:
        if not available_sources(self._service):
            return ShellState()
        return self._shell_state

    def _selection_cache_key(self, state: ShellState) -> tuple[str, str]:
        query = state.search_query.strip() if state.base == ShellBase.SEARCH else ""
        return (state.base.value, query)

    def _selection_identity_changed(self, previous: ShellState, current: ShellState) -> bool:
        if previous.base != current.base:
            return True
        if current.base == ShellBase.SEARCH and previous.search_query != current.search_query:
            return True
        return False

    def _cache_matches(self, state: ShellState) -> bool:
        return (
            self._cached_selection_key is not None
            and self._cached_selection_key == self._selection_cache_key(state)
        )

    def _invalidate_selection_cache(self) -> None:
        self._cached_selection_key = None
        self._cached_releases = []

    def _store_selection_cache(self, state: ShellState, releases: list[Release]) -> None:
        self._cached_selection_key = self._selection_cache_key(state)
        self._cached_releases = list(releases)

    def _filtered_from_cache(self, state: ShellState) -> list[Release]:
        return apply_source_filter(self._cached_releases, state.enabled_sources)

    def _display_cached_selection(self, state: ShellState | None = None) -> None:
        state = state or self._effective_shell_state()
        if not self._cache_matches(state):
            self._reload_grid()
            return
        releases = self._filtered_from_cache(state)
        self._show_grid(
            releases=releases,
            empty_message=self._empty_message(state, releases),
            title=self._grid_title(state),
        )

    def _set_shell_state(self, state: ShellState, *, reload: bool = True) -> None:
        identity_changed = self._selection_identity_changed(self._shell_state, state)
        if identity_changed:
            state = ShellState(
                base=state.base,
                search_query=state.search_query,
                enabled_sources=state.enabled_sources,
                cached_releases=(),
            )
        self._shell_state = state
        self._sync_shell_controls()
        self._schedule_persist()
        if not reload:
            return
        if identity_changed:
            self._invalidate_selection_cache()
            self._reload_grid()
        else:
            self._display_cached_selection(state)

    def _sync_shell_controls(self) -> None:
        state = self._shell_state
        self._updating_preset = True
        try:
            self._new_music_btn.set_active(state.base == ShellBase.NEW_MUSIC)
            self._suggestion_btn.set_active(state.base == ShellBase.SUGGESTION)
        finally:
            self._updating_preset = False

        if state.base == ShellBase.SEARCH:
            current = self._search_entry.get_text()
            if current != state.search_query:
                self._search_entry.set_text(state.search_query)
        elif state.base in (ShellBase.NEW_MUSIC, ShellBase.SUGGESTION):
            if self._search_entry.get_text():
                self._search_entry.set_text("")

        self._sync_source_multi()

    def _rebuild_source_filters(self) -> None:
        sources = available_sources(self._service)
        if len(sources) <= 1:
            self._source_row.set_visible(False)
            if self._shell_state.enabled_sources:
                self._shell_state = ShellState(
                    base=self._shell_state.base,
                    search_query=self._shell_state.search_query,
                    enabled_sources=frozenset(),
                )
            self._source_multi = None
            child = self._source_row.get_first_child()
            while child is not None:
                next_child = child.get_next_sibling()
                self._source_row.remove(child)
                child = next_child
            return

        self._source_row.set_visible(True)
        if self._source_multi is None:
            self._source_multi = SourceMultiSwitch(
                sources=sources,
                enabled_sources=self._shell_state.enabled_sources,
                on_changed=self._on_source_multi_changed,
            )
            self._source_row.append(self._source_multi)
        else:
            self._source_multi.set_sources(sources, self._shell_state.enabled_sources)

    def _sync_source_multi(self) -> None:
        if self._source_multi is not None:
            self._source_multi.set_enabled_sources(self._shell_state.enabled_sources)

    def _on_source_multi_changed(self, enabled_sources: frozenset[Source]) -> None:
        self._set_enabled_sources(enabled_sources)

    def _set_enabled_sources(self, enabled_sources: frozenset[Source]) -> None:
        state = self._shell_state
        if state.enabled_sources == enabled_sources:
            return
        self._shell_state = ShellState(
            base=state.base,
            search_query=state.search_query,
            enabled_sources=enabled_sources,
        )
        self._sync_source_multi()
        self._schedule_persist()
        self._display_cached_selection()

    def _on_new_music_toggled(self, button: Gtk.ToggleButton) -> None:
        if getattr(self, "_updating_preset", False):
            return
        if button.get_active():
            self._activate_preset(ShellBase.NEW_MUSIC)
        elif self._shell_state.base == ShellBase.NEW_MUSIC:
            button.set_active(True)

    def _on_suggestion_toggled(self, button: Gtk.ToggleButton) -> None:
        if getattr(self, "_updating_preset", False):
            return
        if button.get_active():
            self._activate_preset(ShellBase.SUGGESTION)
        elif self._shell_state.base == ShellBase.SUGGESTION:
            button.set_active(True)

    def _activate_preset(self, base: ShellBase) -> None:
        self._set_shell_state(
            ShellState(
                base=base,
                search_query="",
                enabled_sources=self._shell_state.enabled_sources,
            ),
        )

    def _on_search_activate(self, entry: Gtk.SearchEntry) -> None:
        query = entry.get_text().strip()
        if not query:
            return
        self._set_shell_state(
            ShellState(
                base=ShellBase.SEARCH,
                search_query=query,
                enabled_sources=self._shell_state.enabled_sources,
            ),
        )

    def _schedule_persist(self) -> None:
        if self._persist_timeout_id:
            GLib.source_remove(self._persist_timeout_id)
        self._persist_timeout_id = GLib.timeout_add(
            _PERSIST_DEBOUNCE_MS,
            self._persist_shell_state,
        )

    def _shell_state_for_persist(self) -> ShellState:
        state = self._shell_state
        cached_payloads: tuple[dict, ...] = ()
        if self._cache_matches(state) and self._cached_releases:
            cached_payloads = tuple(
                release_to_cache_payload(release) for release in self._cached_releases
            )
        return ShellState(
            base=state.base,
            search_query=state.search_query,
            enabled_sources=state.enabled_sources,
            cached_releases=cached_payloads,
        )

    def _persist_shell_state(self) -> bool:
        self._persist_timeout_id = 0
        self._service.config.set_shell_state(self._shell_state_for_persist())
        return False

    def _on_close_request(self, *_args: object) -> bool:
        if self._persist_timeout_id:
            GLib.source_remove(self._persist_timeout_id)
            self._persist_timeout_id = 0
        self._service.config.set_shell_state(self._shell_state_for_persist())
        return False

    def _try_restore_persisted_grid(self, state: ShellState) -> bool:
        if state.base == ShellBase.NONE or not state.cached_releases:
            return False
        releases = releases_from_cache_payloads(state.cached_releases)
        if not releases:
            return False
        self._store_selection_cache(state, releases)
        filtered = self._filtered_from_cache(state)
        self._show_grid(
            releases=filtered,
            empty_message=self._empty_message(state, filtered),
            title=self._grid_title(state),
        )
        return True

    def _reload_grid(self) -> bool:
        state = self._effective_shell_state()

        if self._try_restore_persisted_grid(state):
            return False

        if state.base in (ShellBase.NEW_MUSIC, ShellBase.SUGGESTION):
            self._start_async_load(state.base)
            return False

        releases = fetch_base_releases(
            self._service,
            state.base,
            search_query=state.search_query,
        )
        self._store_selection_cache(state, releases)
        filtered = self._filtered_from_cache(state)
        self._show_grid(
            releases=filtered,
            empty_message=self._empty_message(state, filtered),
            title=self._grid_title(state),
        )
        self._schedule_persist()
        return False

    def _start_async_load(self, base: ShellBase) -> None:
        self._load_token += 1
        token = self._load_token
        self._show_grid_loading(base)

        def work() -> None:
            try:
                releases = fetch_base_releases(self._service, base)
                GLib.idle_add(self._finish_async_load, token, base, releases, None)
            except Exception as exc:
                log.exception("Shell load failed for %s", base.value)
                GLib.idle_add(self._finish_async_load, token, base, None, exc)

        threading.Thread(target=work, daemon=True).start()

    def _finish_async_load(
        self,
        token: int,
        base: ShellBase,
        releases: list | None,
        error: BaseException | None,
    ) -> bool:
        if token != self._load_token:
            return False
        if self._shell_state.base != base:
            return False

        label = _PRESET_LABELS[base]
        if error is not None:
            show_error_toast(
                self._toast_overlay,
                f"Could not load {label}. Check your connection and sign-in.",
            )
            view = PlaceholderView(
                title=label,
                message=f"Could not load {label}. Try again in a moment.",
            )
            self._replace_root_page(title=label, child=view)
            return False

        loaded = releases or []
        self._store_selection_cache(self._shell_state, loaded)
        filtered = self._filtered_from_cache(self._shell_state)
        self._show_grid(
            releases=filtered,
            empty_message=self._empty_message(self._shell_state, filtered),
            title=label,
        )
        self._schedule_persist()
        return False

    def _show_grid_loading(self, base: ShellBase) -> None:
        title = _PRESET_LABELS[base]
        message = _LOADING_MESSAGES.get(base, f"Loading {title}…")
        self._replace_root_page(
            title=title,
            child=LoadingDiscoverView(message=message),
        )

    def _show_grid(
        self,
        *,
        releases: list,
        empty_message: str | None,
        title: str,
    ) -> None:
        view = ReleaseGridView(
            releases=releases,
            on_release_activated=self._open_release,
            on_release_play=lambda release_id: self._service.play_release(
                release_id, start_index=0
            ),
            empty_message=empty_message,
            art_loader=self._art_loader,
            window_inner_width_fn=self._album_grid_inner_width,
        )
        self._replace_root_page(title=title, child=view)

    def _empty_message(self, state: ShellState, releases: list) -> str | None:
        if releases:
            return None
        if not available_sources(self._service):
            return _ONBOARDING_MESSAGE
        if state.base == ShellBase.NONE:
            return _ONBOARDING_MESSAGE
        if state.base == ShellBase.SEARCH:
            if not state.search_query.strip():
                return _ONBOARDING_MESSAGE
            return f'No results for “{state.search_query}”.'
        if state.base == ShellBase.NEW_MUSIC:
            days = self._service.config.config.new_music_within_days
            return (
                f"Nothing new in the last {days} days.\n"
                "Add music folders or sign in to TIDAL or Qobuz in Settings → Sources."
            )
        if state.base == ShellBase.SUGGESTION:
            return (
                "Play music to build suggestions from your library, or sign in to "
                "TIDAL or Qobuz in Settings → Sources."
            )
        if state.enabled_sources:
            names = ", ".join(
                source_label(source)
                for source in sorted(state.enabled_sources, key=lambda s: s.value)
            )
            return f"No releases from {names} in this selection."
        return None

    def _grid_title(self, state: ShellState) -> str:
        if state.base == ShellBase.SEARCH and state.search_query.strip():
            return state.search_query
        return _PRESET_LABELS.get(state.base, "Tunes")

    def _replace_root_page(self, *, title: str, child: Gtk.Widget) -> None:
        self._pop_to_root()
        current = self._main_nav.get_visible_page()
        if current is not None and current.get_tag() == _GRID_ROOT_TAG:
            current.set_child(child)
            current.set_title(escape_markup(title))
            return
        self._main_nav.add(
            Adw.NavigationPage(
                title=escape_markup(title),
                child=child,
                tag=_GRID_ROOT_TAG,
            ),
        )

    def _release_id_for_current_view(self) -> str | None:
        page = self._main_nav.get_visible_page()
        if page is None:
            return None
        tag = page.get_tag()
        if not tag or tag == _GRID_ROOT_TAG:
            return None
        release = self._service.get_release(tag)
        return tag if release is not None else None

    def _on_play_clicked(self) -> None:
        state = self._service.get_playback_state()
        if state.current_track is None and not state.queue:
            release_id = self._release_id_for_current_view()
            if release_id is not None:
                self._service.play_release(release_id, start_index=0)
                return
        self._service.toggle_play_pause()

    def _open_release(self, release_id: str) -> None:
        release = self._service.get_release(release_id)
        if release is None:
            return
        detail = ReleaseDetailView(
            service=self._service,
            release=release,
            art_loader=self._art_loader,
            on_artist_search=self._search_for_artist,
        )
        page = Adw.NavigationPage(
            title=escape_markup(release.title),
            child=detail,
            tag=release_id,
        )
        self._pop_to_root()
        self._main_nav.push(page)
        self._sync_header_with_nav()

    def _search_for_artist(self, artist_name: str) -> None:
        if not self._nav_at_root():
            self._main_nav.pop()
        self._search_entry.set_text(artist_name)
        self._set_shell_state(
            ShellState(
                base=ShellBase.SEARCH,
                search_query=artist_name,
                enabled_sources=self._shell_state.enabled_sources,
            ),
        )

    def _open_preferences(self, *_args: object) -> None:
        if self._preferences is None:
            self._preferences = PreferencesWindow(parent=self, service=self._service)
            self._preferences.connect(
                "close-request",
                lambda *_: setattr(self, "_preferences", None) or False,
            )
        self._preferences.present()

    def _startup_playback_probe(self) -> bool:
        message = self._service.playback_available()
        if message:
            show_error_toast(self._toast_overlay, message)
        return False

    def _on_service_event(self, event: str) -> bool:
        if event == "library_updated":
            GLib.idle_add(self._on_sources_or_library_changed)
        elif event == "sources_changed":
            GLib.idle_add(self._on_sources_or_library_changed)
        return False

    def _on_sources_or_library_changed(self) -> bool:
        self._rebuild_source_filters()
        self._invalidate_selection_cache()
        self._reload_grid()
        return False

    def _open_queue_sheet(self, *_args: object) -> None:
        if self._queue_sheet is None:
            self._queue_sheet = QueueSheet(service=self._service)
            self._queue_sheet.connect("closed", lambda *_: setattr(self, "_queue_sheet", None))
        self._queue_sheet.present(self)

    def _pop_to_root(self) -> None:
        page = self._main_nav.get_visible_page()
        while page is not None and page.get_tag() != _GRID_ROOT_TAG:
            self._main_nav.pop()
            page = self._main_nav.get_visible_page()

    def _nav_at_root(self) -> bool:
        page = self._main_nav.get_visible_page()
        if page is None:
            return True
        return page.get_tag() == _GRID_ROOT_TAG

    def _sync_header_with_nav(self) -> None:
        at_root = self._nav_at_root()
        self._shell_controls.set_visible(at_root)
        self._back_btn.set_visible(not at_root)

    def _on_nav_back(self, *_args: object) -> None:
        if self._nav_at_root():
            return
        self._main_nav.pop()

    def _on_nav_visible_page_changed(self, *_args: object) -> None:
        self._sync_header_with_nav()


def run() -> int:
    from tunes_player.core.config import ConfigManager

    load_app_css()
    config = ConfigManager()
    config.load()
    configure_logging(config.data_dir)
    volume_controller = create_volume_controller(config.config)
    service = PlayerService(config=config, volume_controller=volume_controller)
    mpris_service = None

    class TunesApplication(Adw.Application):
        def do_activate(self) -> None:  # noqa: N802 — GTK vfunc
            window = self.get_active_window()
            if window is None:
                window = TunesWindow(application=self, service=service)
            window.present()

        def do_shutdown(self) -> None:  # noqa: N802 — GTK vfunc
            nonlocal mpris_service
            if mpris_service is not None:
                mpris_service.stop()
                mpris_service = None
            service.shutdown()
            Adw.Application.do_shutdown(self)

    app = TunesApplication(application_id="tunes.player")

    def _raise_app() -> None:
        window = app.get_active_window()
        if window is not None:
            window.present()

    from tunes_player.platform.linux.mpris import create_mpris_service

    mpris_service = create_mpris_service(
        service,
        on_raise=_raise_app,
        on_quit=app.quit,
    )
    mpris_service.start()

    def _poll_playback() -> bool:
        service.poll_playback()
        return True

    GLib.timeout_add(100, _poll_playback)
    return app.run(None)
