"""Map tidalapi objects to Tunes domain models."""

from __future__ import annotations

from typing import TYPE_CHECKING

from tunes_player.core.backends.tidal import ids as tidal_ids
from tunes_player.core.models import (
    Artist,
    Release,
    ReleaseCompleteness,
    ReleaseType,
    Source,
    Track,
)

if TYPE_CHECKING:
    from tidalapi.album import Album as TidalAlbum
    from tidalapi.artist import Artist as TidalArtist
    from tidalapi.media import Track as TidalTrack
    from tidalapi.session import Session


def _album_art(session: Session, album: TidalAlbum, *, size: int = 320) -> str | None:
    try:
        return album.image(size)
    except Exception:
        return None


def release_from_tidal(session: Session, album: TidalAlbum, *, owned_track_count: int | None = None) -> Release:
    artists = album.artists or []
    artist_name = artists[0].name if artists else "Unknown Artist"
    year = None
    if album.release_date is not None:
        year = album.release_date.year
    expected = int(album.num_tracks or 0) or None
    track_count = owned_track_count if owned_track_count is not None else (expected or 0)
    if expected is not None and track_count < expected:
        completeness = ReleaseCompleteness.PARTIAL
        release_type = ReleaseType.ALBUM
    elif track_count == 1:
        completeness = ReleaseCompleteness.COMPLETE
        release_type = ReleaseType.SINGLE
    else:
        completeness = ReleaseCompleteness.COMPLETE
        release_type = ReleaseType.ALBUM
    return Release(
        id=tidal_ids.album_id(album.id),
        title=album.name or "Unknown",
        artist_name=artist_name,
        source=Source.TIDAL,
        year=year,
        track_count=track_count,
        expected_track_count=expected,
        completeness=completeness,
        release_type=release_type,
        art_uri=_album_art(session, album),
    )


def album_from_tidal(session: Session, album: TidalAlbum) -> Release:
    return release_from_tidal(session, album)


def artist_from_tidal(artist: TidalArtist) -> Artist:
    return Artist(
        id=tidal_ids.artist_id(artist.id),
        name=artist.name or "Unknown Artist",
        source=Source.TIDAL,
    )


def track_from_tidal(session: Session, track: TidalTrack, *, album: TidalAlbum | None = None) -> Track:
    artists = track.artists or []
    artist_name = artists[0].name if artists else "Unknown Artist"
    album_title = None
    art_uri = None
    if album is not None:
        album_title = album.name
        art_uri = _album_art(session, album)
    elif track.album is not None:
        album_title = track.album.name
        art_uri = _album_art(session, track.album)
    duration = None
    if track.duration is not None:
        duration = float(track.duration)
    track_number = getattr(track, "track_num", None)
    disc_number = getattr(track, "volume_num", None)
    return Track(
        id=tidal_ids.track_id(track.id),
        title=track.name or "Unknown Track",
        artist_name=artist_name,
        album_title=album_title,
        source=Source.TIDAL,
        duration_sec=duration,
        art_uri=art_uri,
        track_number=int(track_number) if track_number is not None else None,
        disc_number=int(disc_number) if disc_number is not None else None,
    )
